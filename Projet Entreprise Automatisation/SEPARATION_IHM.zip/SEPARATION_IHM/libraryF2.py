# Librairies utilisées dans le projet :

import cv2 # OpenCV -> reconnaissance d'images
import mss # Multi ScreenShot -> OpenCV ne capture que l'écran principal, mss va servir à capturer d'éventuels autres écrans
import numpy as np # numpy est nécessaire afin d'effectuer des opérations mathématiques lors de l'utilisations de certaines librairies et/ou dans le code
import pyautogui # pyautogui sert à déplacer la souris sur des coordonnées de l'écran et de cliquer dessus
import time # lorsqu'il faut attendre dans le programme (chargements lors des lancements de logiciels)
import glob # Utilisé dans la fonction 'runLastDownload' (peut être dans d'autres fonctions voir avec le temps)
import os # Utilisé dans la fonction 'runLastDownload' (peut être dans d'autres fonctions voir avec le temps)
import logging # Utilisé dans la classe 'StreamToLogger' pour récupérer tous les prints et générer un rapport de logs.
import sys # Utilisé dans la classe 'StreamToLogger' pour récupérer tous les prints et générer un rapport de logs. (peut être dans d'autres fonctions voir avec le temps)
import datetime # Utilisé dans la classe 'StreamToLogger' pour créer des fichiers de logs avec l'heure de création comme nom.
import signal # Utilisé pour gérer la condition de CTRL+C et ne pas créer d'erreur dans le programme.
import keyboard # Ajouter un raccourci pour faire un arrêt d'urgence sur le programme peu importe où l'on se trouve.
import threading # la fonction emergency_stop() est appelée dans un thread différent de celui où le programme principal s'exécute, il faut join() pour que 
import webbrowser # Gain de temps, cette librairie permet d'ouvrir un lien avec notre navigateur par défaut. Utilisé pour lancer CyberArk.



# Doc de la fonction find and click :
# En deuxième paramètre :
# 0 -> trouver l'image sans réaliser d'actions dessus
# 1 -> faire un simple click
# 2 -> faire un double click
# 3 -> faire un seul click mais à des coordonnées différentes (anciennement utilisé pour cliquer sur les OMC, à présent une nouvelle technique est employée)
# 4 -> deux simples cliques espacés d'une seconde : un simple click ne suffit pas et le doubleClick est trop rapide pour cliquer sur les searchbar il est donc nécessaire d'ajouter cette fonction.
#