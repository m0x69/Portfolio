# id.py
uid = "u259716"
sessionID = "mhadjras"
sessionMP = "Soleil.12341"
omcNAxMP = "OMC.Soleil1234"
rID = "ru259716"
rPass = "Rlune.12341"

