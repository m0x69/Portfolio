from libraryF2 import *
from gestion_images import *
from screenConf import *
from ids import *

###############################################################################
########### RAPPORT DE LOGS ###################################################
###############################################################################




# Il faudrait que le rapport de logs stock chaque lancement d'application en créant un fichier différent a chaque fois 
# Il faut que ces fichiers soient stockés dans un dossier conçu pour les logs 

# Création d'un gestionnaire personnalisé pour rediriger stdout vers un fichier
class StreamToLogger:
    #Classe pour rediriger stdout vers le logger.
    def __init__(self, logger, log_level=logging.INFO):
        """
        Initialisation du gestionnaire personnalisé.
        """
        self.logger = logger
        self.log_level = log_level
        self.linebuf = ''  # Buffer pour stocker les lignes

        # Création du dossier pour les logs s'il n'existe pas
        log_dir = 'logs'
        if not os.path.exists(log_dir):
            os.makedirs(log_dir)

        # Création du nom du fichier de logs avec la date et l'heure actuelles
        log_filename = datetime.datetime.now().strftime('%Y-%m-%d_%Hh_%Mm_%Ss') + '.txt'
        self.log_file_path = os.path.join(log_dir, log_filename)

        # Configuration du logging pour écrire dans le fichier de logs
        logging.basicConfig(level=logging.INFO,
                            format='%(asctime)s - %(levelname)s - %(message)s',
                            handlers=[logging.FileHandler(self.log_file_path, encoding='utf-8'), logging.StreamHandler()])

    def write(self, buf):
        # Écrire le buffer dans le logger avec le niveau approprié.
        # Redirection de sys.stdout vers StreamToLogger (au cas où elle aurait été modifiée)
        sys.stdout = self
        
        # Ajoute le contenu du buffer au buffer ligne par ligne
        self.linebuf += buf
        
        # Si le buffer contient au moins une ligne complète
        if '\n' in self.linebuf:
            lines = self.linebuf.splitlines(keepends=True)
            for line in lines[:-1]:
                self.logger.log(self.log_level, line.rstrip())
            self.linebuf = lines[-1]

    def flush(self):
    # Vider le buffer.
        pass # Vide le buffer en ne faisant rien (méthode obligatoire pour la classe)
    
    def write_to_stdout(self, buf):
        # Écrire le buffer directement à sys.stdout.
        sys.stdout.write(buf)
# Redirection de stdout vers le gestionnaire personnalisé
sys.stdout = StreamToLogger(logging.getLogger('STDOUT'), logging.INFO) # Redirige stdout vers le gestionnaire personnalisé

# Gérer l'affichage dans les logs de la saisie de la commande CTRL+C
###############################################################################
########### ARRET D'URGENCE ###################################################
###############################################################################





###############################################################################
########### CHARGER LES IMAGES ################################################
###############################################################################

# Charger les images dans baseImages
# Chargement des images

def load_images(baseImages, IMAGE_PATHS):
    for i in IMAGE_PATHS:
        template = cv2.imread(i['path'], cv2.IMREAD_GRAYSCALE)
        baseImages.append(template)
    return baseImages

baseImages = load_images([],IMAGE_PATHS)

###############################################################################

# Donner en paramètres de cette fonction le texte à saisir dans la barre de recherche du menu windows et la fonction lancera l'application trouvée.
def launch_via_win(app):
    # Appuyer sur la touche Windows
    pyautogui.press('win')

    # Attendre un bref délai pour que le menu Windows apparaisse
    time.sleep(1)

    pyautogui.write(app)

    time.sleep(0.5)

    pyautogui.press('enter')

def chrome():
    launch_via_win('Google Chrome')

# Nécessite le u ID.
# Ce programme récupère le dernier fichier ajouté dans téléchargements et le lance.
# Librairies utilisées : 'os' et 'glob'
def runLastDownload():
    # Chemin vers le dossier de téléchargement
    print(uid)
    download_folder = f"C:/Users/{uid}/Downloads"
    # C:\Users\u259716\Downloads

    # Recherche du dernier fichier téléchargé dans le dossier
    list_of_files = glob.glob(download_folder + '/*')
    latest_file = max(list_of_files, key=os.path.getctime)

    # Ouvrir le dernier fichier téléchargé
    os.startfile(latest_file)

# Lance la fonction 'findCitrixGateWay' avec le nom de l'image correspondante
def connectIDcitrix():
    
    if (findCitrixGateWay('CitrixGatewayLogin')==0) :
        return 0
    return 1

# Cherche la page de connexion de Citrix et saisi mot de passe et identifiant 'ru'
def findCitrixGateWay(image_name):

    index = get_index(image_name)
    print("\n_________________________________________________________________________")
    print(f"(findCitrixGateWay)> indice de l'image dans la BD : {get_index(image_name)}")
    imageLoaded = baseImages[index]

    start_time = time.time()

    while time.time() - start_time < 300:  # Recherche pendant 5 minute
        print(f"(findCitrixGateWay)> recherche de '{image_name}' en cours...\n")

        time.sleep(0.25) # Une tentative toutes les X secondes

        for screen_config in SCREEN_CONFIGURATIONS:
            # Capture d'écran
            img = capture_screen(screen_config)
            
            # Détection de l'icône
            icon_detected,max_loc,max_val = detect_icon(img, imageLoaded)

            # Vérification si l'icône est trouvée sur cet écran
            if icon_detected:
                print("(findCitrixGateWay)> Image trouvée.\n")

                click_on_bottom(screen_config, max_loc,height=50,width=0)
                
                pyautogui.press('tab')
                pyautogui.write(rID)
                pyautogui.press('tab')
                pyautogui.write(rPass)
                pyautogui.press('enter')
                pyautogui.press('tab')
                pyautogui.press('enter')
                
                print("(findCitrixGateWay)> Localisation supérieure gauche de l'image : ",max_loc)
                print("(findCitrixGateWay)> Ressemblance de l'image : ",max_val,"\n")
                return 0  # Sort de la fonction si l'image est trouvée   
        print("(findCitrixGateWay)> Image non détectée. (3 écrans)")
    print("(findCitrixGateWay)> La recherche a échoué : l'image n'a pas été trouvée en 30 secondes.")
    print("_________________________________________________________________________")
    return 1  # Indique que la recherche a échoué   

# Lance l'Citrix en cliquant sur la derniere image téléchargée quand on appuie sur la touche windows et qu'on note 'PSM'
# Cette localisation devrait toujours être celle du dernier Citrix téléchargé
###
#  Remplacé par runLastDownload()
###
"""
def startOMC() :
    pyautogui.press('win')

    # Attendre un bref délai pour que le menu Windows apparaisse
    time.sleep(1)

    pyautogui.write('PSM')

    time.sleep(0.5)

    findStartOMC('StartOMC')
def findStartOMC(image_name):

    index = get_index(image_name)
    print("\n_________________________________________________________________________")
    print("(findStartOMC) indice de l'image dans la BD : ",get_index(image_name))
    imageLoaded = baseImages[index]

    start_time = time.time()


    while time.time() - start_time < 10:  # Recherche pendant 10 secondes
        print("(findStartOMC) recherche de '",image_name,"' en cours...\n")

        time.sleep(0.25) # Une tentative toutes les X secondes

        for screen_config in SCREEN_CONFIGURATIONS:
            # Capture d'écran
            img = capture_screen(screen_config)
            # Détection de l'icône
            icon_detected,max_loc,max_val = detect_icon(img, imageLoaded)
            # Détection de l'icône

            # Vérification si l'icône est trouvée sur cet écran
            if icon_detected:

                click_on_bottom(screen_config, max_loc, 30)
                
                print("(detect_icon) Localisation inférieure gauche de l'image : ",max_loc)
                print("(detect_icon) Ressemblance de l'image : ",max_val,"\n")
                return 0  # Sort de la fonction si l'image est trouvée   
        print("Image non détectée. (3 écrans)")
    print("(findStartOMC) La recherche a échoué : l'image n'a pas été trouvée en 10 secondes.")
    print("_________________________________________________________________________")
    return 1  # Indique que la recherche a échoué   
"""
#################
# Changements relatifs à l'adaptation du programme à tous les ordinateurs. 
# L'accès à CyberArk est différent en fonction des ordinateurs (image différente). Il faudra passer par la barre de lien.
# Nouvelle librairie débloquée : WebBrowser
def CyberArk():
    url = 'https://sentry.snt.private.sfr.com/PasswordVault/logon.aspx?ReturnUrl=%2fPasswordVault%2fdefault.aspx'
    # Ouvrir l'URL dans le navigateur par défaut
    webbrowser.open(url)
    time.sleep(1)
    if find_and_click('citrixConnect',0,60) == 0 :
        time.sleep(1)
        pyautogui.write(sessionID)
        pyautogui.press('tab')
        pyautogui.write(sessionMP)
        pyautogui.press('enter')
    return 0

#################
# Fragmenter le code pour le rendre plus maniable depuis l'application.
#################
def loadCitrix():
    check = 0
    if CyberArk() == 0 :
        time.sleep(0.5)
        if find_and_click('RechercherOMC',1,20) == 0 :
            time.sleep(2)
            pyautogui.write('MyNMS')
            pyautogui.press('enter')
            if find_and_click('downloadOMC',1,20) == 0 :    
                time.sleep(0.4)
                if find_and_click('OkDLomc',1,20) == 0 :
                    # Attendre 5 secondes que le téléchargement se finisse 
                    time.sleep(5)
                    # Lancer le launcher d'OMC qui vient d'être téléchargé
                    runLastDownload()
                    # Citrix devrait être en train de se lancer à ce moment là du programme. 
                    # J'ai laissé 30 secondes aulieu de 10 pour qu'il recherche l'image de connexion à Citrix Gateway car l'ordinateur peut mettre du temps à charger la page.
                    if (connectIDcitrix()==0) :
                        print("\n\n\n\n(loadCitrix)> Attente 5 seconde pour laisser charger Citrix (eviter bug barre de recherche)\n\n\n\n")
                        time.sleep(5) # Attendre 5 secondes aulieu de 2 : laisser le temps à citrix de charger.
                    else: return check+1
                else: return check+1
            else: return check+1
        else: return check+1
    else: return check+1
    print("\n\n\n\n(loadCitrix)> Fin de la fonction loadCitrix\n\n\n\n")
    return check
#################

###############################################################################
########### LANCER GENERATEUR DE TRAMES #######################################
###############################################################################

def generateurDeTrames():
    launch_via_win("Generateur Trame")

###############################################################################
###############################################################################

'''
def chromeOMC():

    if find_and_click('chromeOMC',1,10) == 1 : 
        print("(chromeOMC)> La fonction chromeOMC ne peut pas être executée car l'image n'a pas été trouvée, sortie.")
        return 1
    else :
        findCyberARK('citrixConnect')
    return 0
'''
# Remplacé par CyberArk()
'''
def findCyberARK(image_name):

    index = get_index(image_name)
    print("\n_________________________________________________________________________")
    print("(findCyberARK)> indice de l'image dans la BD : ",get_index(image_name))
    imageLoaded = baseImages[index]

    start_time = time.time()


    while time.time() - start_time < 10:  # Recherche pendant 10 secondes
        print(f"(findCyberARK)> recherche de '{image_name}' en cours...\n")

        time.sleep(0.25) # Une tentative toutes les X secondes

        for screen_config in SCREEN_CONFIGURATIONS:
            # Capture d'écran
            img = capture_screen(screen_config)
            # Détection de l'icône
            icon_detected,max_loc,max_val = detect_icon(img, imageLoaded)
            # Détection de l'icône

            # Vérification si l'icône est trouvée sur cet écran
            if icon_detected:
                print("(findCyberARK)> Image trouvée.\n")
                
                time.sleep(1)
                pyautogui.write(sessionID)
                pyautogui.press('tab')
                pyautogui.write(sessionMP)
                pyautogui.press('enter')
                
                print("(findCyberARK)> Localisation supérieure gauche de l'image : ",max_loc)
                print("(findCyberARK)> Ressemblance de l'image : ",max_val,"\n")
                return 0  # Sort de la fonction si l'image est trouvée   
        print("(findCyberARK)> Image non détectée. (3 écrans)")
    print("(findCyberARK)> La recherche a échoué : l'image n'a pas été trouvée en 10 secondes.")
    print("_________________________________________________________________________")
    return 1  # Indique que la recherche a échoué   
'''
###############################################################################
########### LANCER CLARIFY ####################################################
###############################################################################

def clarify():
    # Appuyer sur la touche Windows
    pyautogui.press('win')

    # Attendre un bref délai pour que le menu Windows apparaisse
    time.sleep(1)

    # Ecrire "clarify" dans la barre de recherche
    pyautogui.write('clarify')
    
    # Attendre un bref délai pour que Clarify apparaisse

    time.sleep(0.5)

    # Appuyer sur la touche Entrée pour lancer la recherche
    pyautogui.press('enter')

    # Attendre un bref délai pour que Clarify se lance

    time.sleep(1)

    # Ecrire "clarify" dans la barre de recherche
    pyautogui.write(sessionID)

    # Appuyer sur la touche Entrée pour valider la saisie
    pyautogui.press('enter')

###############################################################################
###############################################################################

### Actions possibles

# fonction cliquer (en haut)
def click_on_icon(screen, top_left):
    pyautogui.click(screen['left'] + top_left[0], screen['top'] + top_left[1])
    print("(click_on_icon)> Le click a été effectué")

# fonction cliquer 
def click_on_bottom(screen, top_left, height, width):
    pyautogui.click(screen['left'] + top_left[0] + width, screen['top'] + top_left[1] + height)

# fonction double clique
def doubleClick_on_icon(screen, top_left):
    pyautogui.doubleClick(screen['left'] + top_left[0], screen['top'] + top_left[1])
    print("(doubleClick_on_icon)> Le doubleClick a été effectué")

# fonction click wait click (deux cliques séparés par une seconde)
def clickWaitClick_on_icon(screen, top_left):
    pyautogui.click(screen['left'] + top_left[0], screen['top'] + top_left[1])
    time.sleep(1)
    pyautogui.click(screen['left'] + top_left[0], screen['top'] + top_left[1])

    print("(doubleClick_on_icon)> Le doubleClick a été effectué")

def get_index(image_name):
    index = None
    for i, image in enumerate(IMAGE_PATHS):
        if image['nom'] == image_name:
            index = i
            break
    return index

def find_and_click(image_name, nClick,t):

    index = get_index(image_name)
    print("\n_________________________________________________________________________")
    print("(find_and_click)> indice de l'image dans la BD : ",get_index(image_name))
    imageLoaded = baseImages[index]

    start_time = time.time()


    while time.time() - start_time < t:  # Recherche pendant 't' secondes
        print(f"(find_and_click)> recherche de '{image_name}' en cours...\n")

        time.sleep(0.25) # Une tentative toutes les X secondes

        for screen_config in SCREEN_CONFIGURATIONS:
            # Capture d'écran
            img = capture_screen(screen_config)
            # Détection de l'icône
            icon_detected,max_loc,max_val = detect_icon(img, imageLoaded)
            # Détection de l'icône, utiliser ce print que lorsqu'il faut debug le taux de détection
            print("(detect_icon) Ressemblance de l'image : ",max_val,"\n")
            # Vérification si l'icône est trouvée sur cet écran
            if icon_detected:
                print("(find_and_click)> Image trouvée.\n")
                if nClick == 1:
                    click_on_icon(screen_config, max_loc)
                    print("(find_and_click)> NB clicks demandés : 1")
                    print("_________________________________________________________________________")
                elif nClick == 0 : # Sert à trouver une image sans faire d'actions dessus.
                    print("(find_and_click)> Aucun click demandé, image trouvée.")
                elif nClick == 2:
                    doubleClick_on_icon(screen_config, max_loc)
                    print("(find_and_click)> NB clicks demandés : 2")
                    print("_________________________________________________________________________")
                elif nClick == 3: # Réservé aux NAx
                    click_on_bottom(screen_config, max_loc, height= 50, width=50)
                    print("(find_and_click)> NB clicks demandés : 1 (Click personnalisé)")
                elif nClick == 4: # Réservé aux searchbar pour la version IHM
                    clickWaitClick_on_icon(screen_config, max_loc)
                    print("(find_and_click)> NB clicks demandés : 1 (Click personnalisé)")
                else:
                    print("(find_and_click)> Erreur dans l'appel de la fonction (nombre de clicks)")
                    print("_________________________________________________________________________")
                print("(find_and_click)> Localisation supérieure gauche de l'image : ",max_loc)
                print("(find_and_click)> Ressemblance de l'image : ",max_val,"\n")
                return 0  # Sort de la fonction si l'image est trouvée   
        print("(find_and_click)> Image non détectée. (3 écrans)")
    print(f"(find_and_click)> La recherche a échoué : l'image n'a pas été trouvée en '{t}' secondes.")
    print("_________________________________________________________________________")
    return 1  # Indique que la recherche a échoué   

###
# 3 étapes de vérification de l'image : 
#
# - Captures d'écran (avec tous les écrans voir fonction capture_screen)
# - Détection de l'icône dans la capture (voir fonction detect_icon)
# - Si l'icône est détecté alors réaliser des actions dessus (voir # Actions possibles)
    
### Capture et détection

# Capture d'écran des écrans pour les traiter sur OpenCV
def capture_screen(screen_config):
    with mss.mss() as sct:
        img = np.array(sct.grab(screen_config))
    return img

# Utilisation de OpenCV pour trouver un icone sur la capture d'écran
def detect_icon(img, template):
    threshold = 0.7 # Seuil de reconnaissance
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    result = cv2.matchTemplate(gray, template, cv2.TM_CCOEFF_NORMED)
    min_val, max_val, min_loc, max_loc = cv2.minMaxLoc(result)
    # Informe du succes ou de l'échec de la détection.
    if max_val >= threshold:
        return True, max_loc, max_val  # Indique que l'icône est détectée
    else:
        return False, max_loc, max_val # Indique que l'icône n'est pas détectée


######################
######################
####               ###
####   NSN NOKIA   ###
####               ###
######################
######################


# Fonction pour remplacer :
# if (find_and_click(NAx,3,30)==0) : # L'option 3 permets de cliquer sur la position 50X50 (En partant d'en haut à gauche de l'image)
# L'image du NAx peut changer en fonction des maj, y accéder via les touches clavier rends le code plus tolérant au changement.

# Sélectionner le premier OMC à disposition en faisant 3 fois tab après avoir fait la recherche de l'OMC sur la barre de recherche.
def tripleTab():
    for i in range(3):
        pyautogui.press('tab')
        time.sleep(0.2)
    pyautogui.press('enter')
    return 1

#####################################
####### Reprendre à ce moment du code (ajouté pour la verification de la page paramAvance)
#####################################
def fromNAxLogin():
    # Si le logo de login n'est pas présent sur la page et que le programme colle tout de même les données sensibles, une faille de sécurité peut être exploitée.
    if (find_and_click('NAxLogin',1,300)==0) : # L'OMC a 5 minutes pour se lancer.
        
        pyautogui.write(sessionID)
        pyautogui.press('tab')
        pyautogui.write(omcNAxMP)
        pyautogui.press('tab')
        pyautogui.press('enter')
        if (find_and_click('NAxGoSeachAccept',0,60)==0) : # Le paramètre '0' permet de repérer l'image sans effectuer d'actions dessus.
            time.sleep(1) # Laisser le temps au bouton de correctement apparaître.
            if ((find_and_click('NAxAcceptBlack',2,5)==0) or (find_and_click('NAxAcceptWhite',2,5)==0)) : 
                find_and_click('NAxAcceptWhite',2,3) # Le bouton a du mal à fonctionner je re clique dessus au cas où, je ne met pas de conditions car si il n'appuie pas c'est pas grave.
                time.sleep(1) # Laisser apparaître correctement le bouton 'NAxMonitoring'
                if(find_and_click('NAxMonitoring',1,10)==0) :
                    find_and_click('NAxMonitor',1,10)
                    time.sleep(1.5) # Attendre que le bouton OKrun devienne cliquable.
                    # if ((find_and_click('NAxOKrunBlue',1,5)==0) or (find_and_click('NAxOKrunGray',1,5)==0)) :
                    #     time.sleep(0.25)
                    if (find_and_click('NAxContinue',1,60)==0) : 
                        for i in range(3):
                            # Le chargement du NSN fait souvent planter le programme, 10 secondes ne suffisent pas. -> 20 secondes
                            if (find_and_click('NAxAcceptRisk',1,120)==0) :
                                find_and_click('NAxRun',1,20)
                                time.sleep(0.5)
                            else : 
                                print("(lancerNAx)> L'icône 'NAxAcceptRisk' n'a pas été trouvé.")
                                return 1
                    else : 
                        print("(lancerNAx)> L'icône 'NAxContinue' n'a pas été trouvé.")
                        return 1
                    # else : 
                    #     print("(lancerNAx)> Les icônes 'NAxOKrunBlue' ou 'NAxOKrunGray' n'ont pas été trouvés.")
                    #     return 1
                else : 
                    print("(lancerNAx)> L'icône 'NAxMonitoring' n'a pas été trouvé.")
                    return 1
            else : 
                print("(lancerNAx)> Les icônes 'NAxAcceptWhite' ou 'NAxAcceptBlack' n'ont pas été trouvés.")
                return 1
        else :
            print("(lancerNAx)> Le menu pour accepter ne s'est pas présenté durant le temps imparti.")
            return 1
    else :
        print("(lancerNAx)> L'icône 'NAxLogin' n'a pas été trouvé, les mots de passes et ID ne sont pas collés.")
        return 1 # Retourne 1 si le programme n'a pas trouvé l'icône.

def lancerNAx(NAx):

    print(NAx,"\n\n\n\n")

    if ((find_and_click('SearchBar1',4,5)==0) or (find_and_click('SearchBar',4,5)==0)):

        time.sleep(1)
        pyautogui.hotkey('ctrl', 'a')
        pyautogui.write(NAx)
        time.sleep(1) # Laisser le temps d'apparaître à la recherche.
        # Cliquer sur l'icône de l'OMC pris en entrée

        if (tripleTab()==1) :
            
            # Changement dans l'interface voici la partie du code permettant de passer une nouvelle page de vérification.
            if (find_and_click('paramAvance',1,10)==0) :
                time.sleep(1)
                pyautogui.press('tab')
                pyautogui.press('enter')
                ##############################################################################################################
                fromNAxLogin()
            else :
                print("(lancerNAx)> La page de parametres avancés ne semble pas s'être affichée, cette étape n'est pas indispensable au lancement de l'OMC.")
                fromNAxLogin()
        else : 
            print(f"(lancerNAx)> L'icône de l'OMC '{NAx}' n'a pas été trouvé")
            return 1
        
    return 0 # Retourne 0 si le programme s'est lancé correctement.

def ajouterNAx(tabomc):
    # Le premier OMC a déjà été lancé par la fonction précédente donc on le retire du tableau.
    tabomc.pop(0)
    if(len(tabomc)>=1):
        for i in range(len(tabomc)) :
            if (find_and_click('newOMC',1,10)== 0) :
                time.sleep(1) # Laisser le temps à la page Citrix de charger.
                if (lancerNAx(tabomc[i])==0) :
                    print(f"(ajouterNAx)> '{tabomc[i]}' a été lancé avec succès.")

                else :
                    print(f"(ajouterNAx)> '{tabomc[i]}' n'a pas pu être lancé correctement.")
                    return 1
            else :
                print("(ajouterNAx)> L'icône de citrix n'a pas été trouvé dans la barre des tâches")
                return 1
        return 0
    else : 
        print("(ajouterNAx)> Il n'y a qu'un seul OMC à lancer, fin du programme.\n")
        return 0

def lancerPremNAx(tabomc):
    if (len(tabomc)==0):
        print("(lancerPremNAx)> La liste des OMC à lancer est vide.")
    else :
        if (lancerNAx(tabomc[0])==0):
            print(f"(lancerPremNAx)> '{tabomc[0]}' a été lancé avec succès.")
            if (find_and_click('NAxDone',0,120)== 0) :

                ajouterNAx(tabomc)

            else :
                print("(lancerPremNAx)> L'image de référence témoin du lancement de l'OMC n'est pas détectée.")
                return 1
        else : 
            print("(lancerPremNAx)> Les OMC n'ont pas pu être lancés correctement.")
            return 1
    return 0