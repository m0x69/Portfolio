# Définition des configurations d'écran
SCREEN_CONFIGURATIONS = [
    {"top": 0, "left": 0, "width": 1920, "height": 1080},  # Écran central
    {"top": -1080, "left": -1920, "width": 1920, "height": 1080},  # Écran à droite
    {"top": -1080, "left": 0, "width": 1920, "height": 1080}  # Écran à gauche
]

'''

SCREEN_CONFIGURATIONS = [
    {"top": 0, "left": -1920, "width": 1920, "height": 1080},  # Écran à droite
    {"top": 0, "left": 0, "width": 1920, "height": 1080}  # Écran à gauche²
]

SCREEN_CONFIGURATIONS = [
    {"top": 0, "left": 0, "width": 1920, "height": 1080}  # Écran à gauche
]

'''