import tkinter as tk
from tkinter import ttk
from functions import (
    manage_key, save_encrypted_data, read_existing_usernames,
    data_update, get_user_data, delete_user_data
)
from functions2 import *
from ids import *

# Fonction pour enregistrer les données
def save_data():
    data = data_entry.get()
    selected_username = username_combobox.get()
    if data and selected_username:
        existing_usernames = read_existing_usernames()
        if selected_username in existing_usernames:
            status_label.config(text=f"Le username '{selected_username}' existe déjà dans le fichier, vous devez le modifier.", fg="red")
            return
        save_encrypted_data(selected_username, data)
        status_label.config(text="Données chiffrées enregistrées avec succès.", fg="green")
        data_entry.delete(0, tk.END)
    else:
        status_label.config(text="Veuillez entrer des données et sélectionner un username.", fg="red")

# Fonction pour afficher la page d'enregistrement
def show_save_page():
    notebook.select(0)

# Fonction pour afficher la page de modification
def show_modify_page():
    notebook.select(1)

# Fonction pour afficher la page OMC
def show_omc_page():
    notebook.select(2)

# Fonction pour afficher les données de l'utilisateur sélectionné
def show_user_data():
    selected_username = modify_username_combobox.get()
    if selected_username:
        user_data = get_user_data(selected_username)
        if user_data:
            user_data_label.config(text=f"Données de l'utilisateur '{selected_username}': {user_data}")
        else:
            user_data_label.config(text=f"Aucune donnée trouvée pour l'utilisateur '{selected_username}'.")
    else:
        user_data_label.config(text="Veuillez sélectionner un utilisateur.")

# Fonction pour enregistrer les modifications de l'utilisateur sélectionné
def save_user_data():
    selected_username = modify_username_combobox.get()
    new_data = modify_data_entry.get()
    if selected_username and new_data:
        data_update(selected_username, new_data)
        status_label_modify.config(text=f"Modifications pour '{selected_username}' enregistrées avec succès.", fg="green")
        modify_data_entry.delete(0, tk.END)
    else:
        status_label_modify.config(text="Veuillez sélectionner un utilisateur et saisir de nouvelles données.", fg="red")

# Fonction pour supprimer les données de l'utilisateur sélectionné
def delete_selected_user_data():
    selected_username = modify_username_combobox.get()
    if selected_username:
        delete_user_data(selected_username)
        user_data_label.config(text=f"Données pour l'utilisateur '{selected_username}' supprimées avec succès.")
    else:
        user_data_label.config(text="Veuillez sélectionner un utilisateur.")

# Fonction pour mettre à jour le tableau tabomc avec les OMC sélectionnés
def update_tabomc():
    global tabomc
    tabomc = []
    if omc_na1.get():
        tabomc.append('NA1')
    if omc_na2.get():
        tabomc.append('NA2')
    if omc_na4.get():
        tabomc.append('NA4')
    if omc_navsr.get():
        tabomc.append('NA VSR')

# Créer une fenêtre principale
root = tk.Tk()
root.title("Gestion des Données OMC")
root.geometry("650x650")
root.configure(bg='#F0F0F0')

# Style des boutons (boutons noirs : #080808)
button_style = {'padx': 10, 'pady': 5, 'bg': '#080808', 'fg': 'white', 'font': ('Helvetica', 12), 'width': 30}

# Style des étiquettes
label_style = {'font': ('Helvetica', 14), 'bg': '#F0F0F0'}

# Créer un Notebook pour gérer les différentes pages
notebook = ttk.Notebook(root)
notebook.pack(fill='both', expand=True, padx=10, pady=10)

###################################################################################################
################## CREATION DES PAGES #############################################################
###################################################################################################

# Créer la page OMC
omc_frame = ttk.Frame(notebook)
notebook.add(omc_frame, text='OMC')

# Créer la page d'enregistrement
save_frame = ttk.Frame(notebook)
notebook.add(save_frame, text='Enregistrement')

# Créer la page de modification
modify_frame = ttk.Frame(notebook)
notebook.add(modify_frame, text='Modification/Suppression')

###################################################################################################
################## PAGE OMC #######################################################################
###################################################################################################

# Définir un style pour le LabelFrame avec une police plus grande et en gras
style = ttk.Style()
style.configure("Large.TLabelframe.Label", font=("Helvetica", 12, "bold"))

# Section pour lancer les applications
app_frame = ttk.LabelFrame(omc_frame, text="Lancer Applications", padding=10, style="Large.TLabelframe")
app_frame.pack(fill='both', expand=True, padx=10, pady=10)

# Lancer Citrix
omc_save_button = tk.Button(app_frame, text="Lancer Citrix", command=lambda: loadCitrix(), **button_style)
omc_save_button.pack(pady=5, anchor='w')

# Lancer NA1
omc_save_button = tk.Button(app_frame, text="Lancer NA1", command=lambda: lancerNAx('NA1'), **button_style)
omc_save_button.pack(pady=5, anchor='w')

# Lancer NA2
omc_save_button = tk.Button(app_frame, text="Lancer NA2", command=lambda: lancerNAx('NA2'), **button_style)
omc_save_button.pack(pady=5, anchor='w')

# Lancer NA4
omc_save_button = tk.Button(app_frame, text="Lancer NA4", command=lambda: lancerNAx('NA4'), **button_style)
omc_save_button.pack(pady=5, anchor='w')

# Lancer NA VSR
omc_save_button = tk.Button(app_frame, text="Lancer NA VSR", command=lambda: lancerNAx('NA VSR'), **button_style)
omc_save_button.pack(pady=5, anchor='w')

# Section pour le premier lancement
first_launch_frame = ttk.LabelFrame(omc_frame, text="Premier Lancement (Beta)", padding=10, style="Large.TLabelframe")
first_launch_frame.pack(fill='both', expand=True, padx=10, pady=10)

# Variables pour les Checkbuttons
omc_na1 = tk.BooleanVar()
omc_na2 = tk.BooleanVar()
omc_na4 = tk.BooleanVar()
omc_navsr = tk.BooleanVar()

# Checklist pour les OMC
omc_checkbutton1 = tk.Checkbutton(first_launch_frame, text="NA1", variable=omc_na1, command=update_tabomc, **label_style)
omc_checkbutton1.pack(pady=5, anchor='w')
omc_checkbutton2 = tk.Checkbutton(first_launch_frame, text="NA2", variable=omc_na2, command=update_tabomc, **label_style)
omc_checkbutton2.pack(pady=5, anchor='w')
omc_checkbutton3 = tk.Checkbutton(first_launch_frame, text="NA4", variable=omc_na4, command=update_tabomc, **label_style)
omc_checkbutton3.pack(pady=5, anchor='w')
omc_checkbutton4 = tk.Checkbutton(first_launch_frame, text="NA VSR", variable=omc_navsr, command=update_tabomc, **label_style)
omc_checkbutton4.pack(pady=5, anchor='w')

# Bouton pour lancer le programme avec tous les OMC sélectionnés (Citrix etc compris)
omc_runAll_button = tk.Button(first_launch_frame, text="Lancer les OMC Sélectionnés", command=lambda: lancerPremNAx(tabomc), **button_style)
omc_runAll_button.pack(pady=5, anchor='w')

###################################################################################################
################## PAGE ENREGISTREMENT ############################################################
###################################################################################################

# Section pour l'enregistrement des données
save_data_frame = ttk.LabelFrame(save_frame, text="Enregistrer les Données", padding=10, style="Large.TLabelframe")
save_data_frame.pack(fill='both', expand=True, padx=10, pady=10)

# Étiquette de statut (page d'enregistrement)
status_label = tk.Label(save_data_frame, text="", **label_style)
status_label.pack(pady=5, anchor='w')

# Zone de saisie pour les données (page d'enregistrement)
data_entry = tk.Entry(save_data_frame, width=40, font=('Helvetica', 12))
data_entry.pack(pady=5, anchor='w')

# Menu déroulant pour les usernames (page d'enregistrement)
username_combobox = ttk.Combobox(save_data_frame, values=['uid', 'sessionID', 'rID', 'omcNAxMP', 'sessionMP', 'rPass'], state="readonly", font=('Helvetica', 12))
username_combobox.pack(pady=5, anchor='w')

# Bouton pour enregistrer les données (page d'enregistrement)
save_button = tk.Button(save_data_frame, text="Enregistrer (Chiffré)", command=save_data, **button_style)
save_button.pack(pady=5, anchor='w')

###################################################################################################
################## PAGE MODIFICATION SUPPRESSION ##################################################
###################################################################################################

# Section pour la modification et suppression des données
modify_data_frame = ttk.LabelFrame(modify_frame, text="Modification/Suppression des Données", padding=10, style="Large.TLabelframe")
modify_data_frame.pack(fill='both', expand=True, padx=10, pady=10)

# Zone de saisie pour les nouvelles données (page de modification)
modify_data_entry = tk.Entry(modify_data_frame, width=40, font=('Helvetica', 12))
modify_data_entry.pack(pady=5, anchor='w')

# Menu déroulant pour les usernames (page de modification)
modify_username_combobox = ttk.Combobox(modify_data_frame, values=['uid', 'sessionID', 'rID', 'omcNAxMP', 'sessionMP', 'rPass'], state="readonly", font=('Helvetica', 12))
modify_username_combobox.pack(pady=5, anchor='w')

# Bouton pour afficher les données de l'utilisateur sélectionné
show_data_button = tk.Button(modify_data_frame, text="Afficher Données", command=show_user_data, **button_style)
show_data_button.pack(pady=5, anchor='w')

# Bouton pour enregistrer les modifications de l'utilisateur sélectionné
save_data_button = tk.Button(modify_data_frame, text="Enregistrer Modification", command=save_user_data, **button_style)
save_data_button.pack(pady=5, anchor='w')

# Bouton pour supprimer les données de l'utilisateur sélectionné
delete_data_button = tk.Button(modify_data_frame, text="Supprimer Utilisateur", command=delete_selected_user_data, **button_style)
delete_data_button.pack(pady=5, anchor='w')

# Étiquette de statut (page de modification)
status_label_modify = tk.Label(modify_data_frame, text="", **label_style)
status_label_modify.pack(pady=5, anchor='w')

# Étiquette pour afficher les données de l'utilisateur (page de modification)
user_data_label = tk.Label(modify_data_frame, text="", **label_style)
user_data_label.pack(pady=5, anchor='w')

#################################################################################################################################################################################
# Lancer la boucle principale de l'interface graphique
root.mainloop()
