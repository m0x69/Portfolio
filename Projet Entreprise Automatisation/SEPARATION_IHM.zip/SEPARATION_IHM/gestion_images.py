
# Base de données qui regroupe les images.

IMAGE_PATHS = [

###
# Partie Chrome
###   
    # {"nom": "recemment", "path": "./OMC_images/recemment.png"}, à présent dans back
    # {"nom": "chromeOMC", "path": "./OMC_images/Chrome/chromeOMC.png"}, remplacé par GoogleChrome par souci d'adaptabilité
    {"nom": "GoogleChrome", "path": "./OMC_images/Chrome/GoogleChrome.png"},
    {"nom": "OkDLomc", "path": "./OMC_images/Chrome/OkDLomc.png"},
    {"nom": "RechercherOMC", "path": "./OMC_images/Chrome/RechercherOMC.png"},
    {"nom": "downloadOMC",'path':'./OMC_images/Chrome/downloadOMC.png'},
    {"nom": "citrixConnect",'path':'./OMC_images/Chrome/CitrixSeConnecter.png'},
    # {"nom": "StartOMC", "path": "./OMC_images/StartOMC.png"}, supprimé, remplacé par la fonction runLastDownload()
###
# Partie Citrix
###
    {"nom": "CitrixGatewayLogin", "path": "./OMC_images/Citrix/citrixGatewaySeConnecter.png"},
    {"nom": "SearchBar1", "path": "./OMC_images/Citrix/SearchBar1.png"},
    {"nom": "SearchBar", "path": "./OMC_images/Citrix/SearchBar.png"},
    {"nom": "SearchBar2", "path": "./OMC_images/Citrix/SearchBar2.png"},
    {"nom": "newOMC", "path": "./OMC_images/Citrix/newOMC.png"},
###
# Partie NAx
###
    {"nom": "NA VSR", "path": "./OMC_images/Citrix/NAx/NAVSR.png"},
    {"nom": "NA1", "path": "./OMC_images/Citrix/NAx/NA1.png"},
    {"nom": "NA2", "path": "./OMC_images/Citrix/NAx/NA2.png"},
    {"nom": "NA4", "path": "./OMC_images/Citrix/NAx/NA4.png"},
    {"nom": "NAxLogin", "path": "./OMC_images/Citrix/NAx/NAxLogin.png"},
    {"nom": "NAxDone", "path": "./OMC_images/Citrix/NAx/NAxDone.png"},
    
    # Cette ligne a été ajoutée suite à la modification de l'interface des OMC nokia.
    ## A présent, une page apparaît pour prévenir l'utilisateur cette image a donc été ajoutée pour rendre le code fonctionnel malgré ce changement.
    ### 29/05/24
    {"nom": "paramAvance", "path": "./OMC_images/Citrix/NAx/paramAvance.png"},

    # Cette image donnera un signal pour commencer à chercher NAxAccept
    {"nom": "NAxGoSeachAccept", "path": "./OMC_images/Citrix/NAx/NAxGoSeachAccept.png"},
    
    # Le NAxAccept peut etre soit Noir soit Blanc
    {"nom": "NAxAcceptBlack", "path": "./OMC_images/Citrix/NAx/NAxAcceptBlack.png"},
    {"nom": "NAxAcceptWhite", "path": "./OMC_images/Citrix/NAx/NAxAcceptWhite.png"},

    {"nom": "NAxMonitoring", "path": "./OMC_images/Citrix/NAx/NAxMonitoring.png"},
    {"nom": "NAxMonitor", "path": "./OMC_images/Citrix/NAx/NAxMonitor.png"},
    # Le OKrun peut etre soit Bleu soit Gris :
    {"nom": "NAxOKrunBlue", "path": "./OMC_images/Citrix/NAx/NAxOKrunBlue.png"},
    {"nom": "NAxOKrunGray", "path": "./OMC_images/Citrix/NAx/NAxOKrunGray.png"},

    {"nom": "NAxContinue", "path": "./OMC_images/Citrix/NAx/NAxContinue.png"},
    {"nom": "NAxAcceptRisk", "path": "./OMC_images/Citrix/NAx/NAxAcceptRisk.png"},
    {"nom": "NAxRun", "path": "./OMC_images/Citrix/NAx/NAxRun.png"}


    
    

]

# Cette liste est vide mais la fonction 'load_images' va la remplir avec les images contenues dans 'IMAGE_PATHS' (voir fonctions.py)
baseImages = []