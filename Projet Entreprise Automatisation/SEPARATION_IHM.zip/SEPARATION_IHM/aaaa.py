import tkinter as tk
from tkinter import ttk
from functions import (
    manage_key, save_encrypted_data, read_existing_usernames,
    data_update, get_user_data, delete_user_data
)
from functions2 import *
from ids import *

# Fonction pour enregistrer les données
def save_data():
    data = data_entry.get()  # Récupérer les données saisies par l'utilisateur
    selected_username = username_combobox.get()  # Récupérer l'username sélectionné
    if data and selected_username:
        existing_usernames = read_existing_usernames()

        # Vérifier si le username sélectionné existe déjà
        if selected_username in existing_usernames:
            status_label.config(text=f"Le username '{selected_username}' existe déjà dans le fichier, vous devez le modifier.", fg="red")
            return

        save_encrypted_data(selected_username, data)
        status_label.config(text="Données chiffrées enregistrées avec succès.", fg="green")
        # Effacer la zone de saisie après l'enregistrement
        data_entry.delete(0, tk.END)
    else:
        status_label.config(text="Veuillez entrer des données et sélectionner un username.", fg="red")

# Fonction pour afficher la page d'enregistrement
def show_save_page():
    notebook.select(0)

# Fonction pour afficher la page de modification
def show_modify_page():
    notebook.select(1)

# Fonction pour afficher la page OMC
def show_omc_page():
    notebook.select(2)

# Fonction pour afficher les données de l'utilisateur sélectionné
def show_user_data():
    selected_username = modify_username_combobox.get()
    if selected_username:
        user_data = get_user_data(selected_username)
        if user_data:
            user_data_label.config(text=f"Données de l'utilisateur '{selected_username}': {user_data}")
        else:
            user_data_label.config(text=f"Aucune donnée trouvée pour l'utilisateur '{selected_username}'.")
    else:
        user_data_label.config(text="Veuillez sélectionner un utilisateur.")

# Fonction pour enregistrer les modifications de l'utilisateur sélectionné
def save_user_data():
    selected_username = modify_username_combobox.get()
    new_data = modify_data_entry.get()
    if selected_username and new_data:
        data_update(selected_username, new_data)
        status_label_modify.config(text=f"Modifications pour '{selected_username}' enregistrées avec succès.", fg="green")
        modify_data_entry.delete(0, tk.END)
    else:
        status_label_modify.config(text="Veuillez sélectionner un utilisateur et saisir de nouvelles données.", fg="red")

# Fonction pour supprimer les données de l'utilisateur sélectionné
def delete_selected_user_data():
    selected_username = modify_username_combobox.get()
    if selected_username:
        delete_user_data(selected_username)
        user_data_label.config(text=f"Données pour l'utilisateur '{selected_username}' supprimées avec succès.")
    else:
        user_data_label.config(text="Veuillez sélectionner un utilisateur.")

# Fonction pour mettre à jour le tableau tabomc avec les OMC sélectionnés
def update_tabomc():
    global tabomc
    tabomc = []
    if omc_var1.get():
        tabomc.append('NA1')
    if omc_var2.get():
        tabomc.append('NA2')
    if omc_var3.get():
        tabomc.append('NA4')
    if omc_var4.get():
        tabomc.append('NA VSR')
    print("OMC sélectionnés:", tabomc)

# Créer une fenêtre principale
root = tk.Tk()
root.title("Enregistrement et affichage de données")

# Définir la taille minimale de la fenêtre
root.minsize(800, 500)

# Créer un Notebook pour gérer les différentes pages
notebook = ttk.Notebook(root)
notebook.pack(fill='both', expand=True)

###################################################################################################
################## CREATION DES PAGES #############################################################
###################################################################################################

# Créer la page OMC
omc_frame = ttk.Frame(notebook)
notebook.add(omc_frame, text='OMC')

# Créer la page d'enregistrement
save_frame = ttk.Frame(notebook)
notebook.add(save_frame, text='Enregistrement')

# Créer la page de modification
modify_frame = ttk.Frame(notebook)
notebook.add(modify_frame, text='Modification/Suppression')

# Style des boutons
button_style = {'padx': 10, 'pady': 5, 'bg': 'lightgray', 'fg': 'black'}

# Étiquette de statut (page d'enregistrement)
status_label = tk.Label(save_frame, text="", fg="black")
status_label.pack(pady=5, anchor='w')

###################################################################################################
################## PAGE OMC #######################################################################
###################################################################################################

# Ajouter des éléments à la page OMC
omc_label = tk.Label(omc_frame, text="Page de lancement des OMC Nokia", font=("Helvetica", 16))
omc_label.pack(pady=20, anchor='w')

# Lancer NA1
omc_save_button = tk.Button(omc_frame, text="Lancer NA1", command=lambda: lancerNAx('NA1'), **button_style)
omc_save_button.pack(pady=5, anchor='w')
# Lancer NA2
omc_save_button = tk.Button(omc_frame, text="Lancer NA2", command=lambda: lancerNAx('NA2'), **button_style)
omc_save_button.pack(pady=5, anchor='w')
# Lancer NA4
omc_save_button = tk.Button(omc_frame, text="Lancer NA4", command=lambda: lancerNAx('NA4'), **button_style)
omc_save_button.pack(pady=5, anchor='w')
# Lancer NA VSR
omc_save_button = tk.Button(omc_frame, text="Lancer NA VSR", command=lambda: lancerNAx('NA VSR'), **button_style)
omc_save_button.pack(pady=5, anchor='w')

# Variables pour les Checkbuttons
omc_var1 = tk.BooleanVar()
omc_var2 = tk.BooleanVar()
omc_var3 = tk.BooleanVar()
omc_var4 = tk.BooleanVar()

# Checklist pour les OMC
omc_checkbutton1 = tk.Checkbutton(omc_frame, text="OMC1", variable=omc_var1, command=update_tabomc)
omc_checkbutton1.pack(pady=5, anchor='w')
omc_checkbutton2 = tk.Checkbutton(omc_frame, text="OMC2", variable=omc_var2, command=update_tabomc)
omc_checkbutton2.pack(pady=5, anchor='w')
omc_checkbutton3 = tk.Checkbutton(omc_frame, text="OMC3", variable=omc_var3, command=update_tabomc)
omc_checkbutton3.pack(pady=5, anchor='w')
omc_checkbutton4 = tk.Checkbutton(omc_frame, text="OMC4", variable=omc_var4, command=update_tabomc)
omc_checkbutton4.pack(pady=5, anchor='w')

# Bouton pour lancer le programme avec tous les OMC sélectionnés (Citrix etc compris)
omc_runAll_button = tk.Button(omc_frame, text="Lancer les OMC Sélectionnés", command=lambda: print("OMC runAll"), **button_style)
omc_runAll_button.pack(pady=5, anchor='w')

###################################################################################################
################## PAGE ENREGISTREMENT ############################################################
###################################################################################################

# Liste des usernames
usernames = ['uid', 'sessionID', 'rID', 'omcNAxMP', 'sessionMP', 'rPass']

# Zone de saisie pour les données (page d'enregistrement)
data_entry = tk.Entry(save_frame, width=40)
data_entry.pack(pady=5, anchor='w')

# Menu déroulant pour les usernames (page d'enregistrement)
username_combobox = ttk.Combobox(save_frame, values=usernames, state="readonly")
username_combobox.pack(pady=5, anchor='w')

# Bouton pour enregistrer les données (page d'enregistrement)
save_button = tk.Button(save_frame, text="Enregistrer (Chiffré)", command=save_data, **button_style)
save_button.pack(pady=5, anchor='w')

###################################################################################################
################## PAGE MODIFICATION SUPPRESSION ##################################################
###################################################################################################

# Zone de saisie pour les nouvelles données (page de modification)
modify_data_entry = tk.Entry(modify_frame, width=40)
modify_data_entry.pack(pady=5, anchor='w')

# Menu déroulant pour les usernames (page de modification)
modify_username_combobox = ttk.Combobox(modify_frame, values=usernames, state="readonly")
modify_username_combobox.pack(pady=5, anchor='w')

# Bouton pour afficher les données de l'utilisateur sélectionné
show_data_button = tk.Button(modify_frame, text="Afficher Données", command=show_user_data, **button_style)
show_data_button.pack(pady=5, anchor='w')

# Bouton pour enregistrer les modifications de l'utilisateur sélectionné
save_data_button = tk.Button(modify_frame, text="Enregistrer Modification", command=save_user_data, **button_style)
save_data_button.pack(pady=5, anchor='w')

# Bouton pour supprimer les données de l'utilisateur sélectionné
delete_data_button = tk.Button(modify_frame, text="Supprimer Utilisateur", command=delete_selected_user_data, **button_style)
delete_data_button.pack(pady=5, anchor='w')

# Étiquette de statut (page de modification)
status_label_modify = tk.Label(modify_frame, text="", fg="black")
status_label_modify.pack(pady=5, anchor='w')

# Étiquette pour afficher les données de l'utilisateur (page de modification)
user_data_label = tk.Label(modify_frame, text="", fg="black")
user_data_label.pack(pady=5, anchor='w')

# Bouton pour afficher la page d'enregistrement
save_page_button = tk.Button(modify_frame, text="Enregistrer", command=show_save_page, **button_style)
save_page_button.pack(pady=5, anchor='w')

#################################################################################################################################################################################
# Lancer la boucle principale de l'interface graphique
root.mainloop()

