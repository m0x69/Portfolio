from cryptography.fernet import Fernet
import os

# Fonction pour générer une clé de chiffrement
def generate_key():
    key = Fernet.generate_key()
    with open('key.key', 'wb') as file:
        file.write(key)
    return key

# Fonction pour chiffrer les données
def encrypt_data(key, data):
    cipher_suite = Fernet(key)
    encrypted_data = cipher_suite.encrypt(data.encode())
    return encrypted_data.decode()

# Fonction pour décrypter les données
def decrypt_data(key, encrypted_data):
    cipher_suite = Fernet(key)
    decrypted_data = cipher_suite.decrypt(encrypted_data.encode())
    return decrypted_data.decode()

# Fonction pour gérer la clé de chiffrement
def manage_key():
    if os.path.exists('key.key') and os.path.getsize('key.key') > 0:
        with open('key.key', 'r') as file:
            key = file.read().strip().encode()
    else:
        key = generate_key()
        with open('key.key', 'w') as file:
            file.write(key.decode())
        print("Nouvelle clé de décryptage générée et stockée dans key.key")
    return key

# Fonction pour lire les usernames existants
def read_existing_usernames():
    existing_usernames = set()
    try:
        with open('encrypted.txt', 'r') as file:
            for line in file:
                username, _ = line.split(':', 1)
                existing_usernames.add(username)
    except FileNotFoundError:
        pass
    return existing_usernames

# Fonction pour enregistrer des données chiffrées
def save_encrypted_data(selected_username, data):
    key = manage_key()
    encrypted_data = encrypt_data(key, data)
    with open('encrypted.txt', 'a') as file:
        file.write(f"{selected_username}:{encrypted_data}\n")

# Fonction pour mettre à jour des données
def data_update(username, new_data):
    key = manage_key()
    updated_line = f"{username}:{encrypt_data(key, new_data)}\n"
    with open('encrypted.txt', 'r+') as file:
        lines = file.readlines()
        for i, line in enumerate(lines):
            if line.startswith(f"{username}:"):
                lines[i] = updated_line
                break
        file.seek(0)
        file.truncate()
        file.writelines(lines)

# Fonction pour afficher les données de l'utilisateur sélectionné
def get_user_data(selected_username):
    try:
        with open('encrypted.txt', 'r') as file:
            for line in file:
                username, encrypted_data = line.split(':', 1)
                if username == selected_username:
                    return decrypt_data(manage_key(), encrypted_data.strip())
    except FileNotFoundError:
        return None
    return None

# Fonction pour supprimer les données de l'utilisateur sélectionné
def delete_user_data(selected_username):
    try:
        with open('encrypted.txt', 'r') as file:
            lines = file.readlines()
        with open('encrypted.txt', 'w') as file:
            for line in lines:
                username, _ = line.split(':', 1)
                if username != selected_username:
                    file.write(line)
    except FileNotFoundError:
        pass
